### Hexlet tests and linter status:
[![Actions Status](https://github.com/shib1991/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/shib1991/python-project-49/actions)
<a href="https://codeclimate.com/github/shib1991/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/b40687401a71039f5497/maintainability" /></a>
Brain_even
https://asciinema.org/a/qQsbfOa6gttG83pUGGydELtMS

Brain_calc
https://asciinema.org/a/nB1rwCQBrYC2HKVFVGttsz0sd

Brain_gcd
https://asciinema.org/a/ltQztGPFVwoneveFqPZuDuJ2k

Brain_progression
https://asciinema.org/a/yiHtyRSDRVOBSAqW6KmGZlUK6

Brain_prime
https://asciinema.org/a/2tliICBFqACavfge481FDrd5w